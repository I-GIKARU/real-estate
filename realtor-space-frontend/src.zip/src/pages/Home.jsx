import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import Header from '../components/Header';
import Footer from '../components/Footer';
import PropertyCard from '../components/PropertyCard';
import { fallbackApi } from '../services/api';

const Home = () => {
  const [featuredProperties, setFeaturedProperties] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadFeaturedProperties = async () => {
      try {
        const response = await fallbackApi.getProperties();
        // Get first 3 properties as featured
        setFeaturedProperties(response.data.properties.slice(0, 3));
      } catch (error) {
        console.error('Error loading featured properties:', error);
      } finally {
        setLoading(false);
      }
    };

    loadFeaturedProperties();
  }, []);

  return (
    <div className="min-h-screen container-fix overflow-x-hidden">
      <Header />
      
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        {/* Animated Background */}
        <div className="absolute inset-0 gradient-shift" style={{
          background: 'linear-gradient(135deg, #667eea 0%, #764ba2 50%, #f093fb 100%)'
        }}></div>
        
        {/* Floating Elements */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-20 left-10 w-72 h-72 bg-white/10 rounded-full blur-xl animate-pulse"></div>
          <div className="absolute bottom-20 right-10 w-96 h-96 bg-white/5 rounded-full blur-2xl float"></div>
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-white/5 rounded-full blur-3xl"></div>
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-32 text-center">
          <div className="fade-in-up">
            <h1 className="text-5xl md:text-7xl lg:text-8xl font-black text-white mb-8 tracking-tight">
              Discover Your
              <span className="block bg-gradient-to-r from-yellow-300 to-pink-300 bg-clip-text text-transparent">
                Dream Property
              </span>
            </h1>
            <p className="text-xl md:text-2xl text-white/90 mb-12 max-w-3xl mx-auto leading-relaxed">
              Experience luxury living with our curated collection of premium properties. 
              Find it. Love it. Live it.
            </p>
            
            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-6 justify-center items-center">
              <Link
                to="/listings"
                className="btn-modern scale-in hover-lift text-xl px-8 py-4"
              >
                <i className="fas fa-home mr-3"></i>
                Explore Properties
              </Link>
              <button className="glass text-white px-8 py-4 rounded-xl font-semibold hover-glow flex items-center text-xl">
                <i className="fas fa-play mr-3"></i>
                Watch Tour
              </button>
            </div>
          </div>
          
          {/* Scroll Indicator */}
          <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-white/70 animate-bounce">
            <i className="fas fa-chevron-down text-2xl"></i>
          </div>
        </div>
      </section>

      {/* Featured Properties Section */}
      <section className="relative py-20 overflow-hidden">
        {/* Background Elements */}
        <div className="absolute inset-0 bg-gradient-to-br from-gray-50 via-white to-purple-50"></div>
        <div className="absolute top-0 left-0 w-96 h-96 bg-purple-100 rounded-full blur-3xl opacity-30 -translate-x-48 -translate-y-48"></div>
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-pink-100 rounded-full blur-3xl opacity-30 translate-x-48 translate-y-48"></div>
        
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <div className="inline-flex items-center px-4 py-2 bg-purple-100 text-purple-700 rounded-full text-sm font-semibold mb-6">
              <i className="fas fa-star mr-2"></i>
              Premium Collection
            </div>
            <h2 className="text-4xl md:text-6xl font-black text-gray-900 mb-6 tracking-tight">
              Featured
              <span className="block bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                Properties
              </span>
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto leading-relaxed">
              Handpicked selection of our most exceptional properties, 
              <span className="text-purple-600 font-semibold">curated just for you</span>
            </p>
          </div>

          {loading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[1, 2, 3].map((i) => (
                <div key={i} className="bg-white rounded-2xl h-96 shadow-xl">
                  <div className="w-full h-64 bg-gradient-to-r from-gray-200 to-gray-300 rounded-t-2xl shimmer"></div>
                  <div className="p-6 space-y-4">
                    <div className="h-4 bg-gradient-to-r from-gray-200 to-gray-300 rounded shimmer"></div>
                    <div className="h-4 bg-gradient-to-r from-gray-200 to-gray-300 rounded w-3/4 shimmer"></div>
                    <div className="h-6 bg-gradient-to-r from-gray-200 to-gray-300 rounded w-1/2 shimmer"></div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {featuredProperties.map((property, index) => (
                <div key={property.id} className="fade-in-up" style={{ animationDelay: `${index * 0.1}s` }}>
                  <PropertyCard
                    property={property}
                    className="hover-lift"
                  />
                </div>
              ))}
            </div>
          )}
          
          <div className="text-center mt-12">
            <Link
              to="/listings"
              className="inline-flex items-center px-8 py-4 bg-gradient-to-r from-purple-600 to-pink-600 text-white font-semibold rounded-2xl hover:shadow-2xl hover:shadow-purple-500/25 transform hover:scale-105 transition-all duration-300"
            >
              <span>View All Properties</span>
              <i className="fas fa-arrow-right ml-2"></i>
            </Link>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="relative py-20 overflow-hidden">
        {/* Background */}
        <div className="absolute inset-0 bg-gradient-to-br from-white via-blue-50 to-purple-50"></div>
        <div className="absolute top-0 right-0 w-96 h-96 bg-blue-100 rounded-full blur-3xl opacity-40 translate-x-48 -translate-y-48"></div>
        
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div className="slide-in-right">
              <div className="inline-flex items-center px-4 py-2 bg-blue-100 text-blue-700 rounded-full text-sm font-semibold mb-6">
                <i className="fas fa-info-circle mr-2"></i>
                Our Story
              </div>
              <h2 className="text-4xl md:text-5xl font-black text-gray-900 mb-6 tracking-tight">
                About
                <span className="block bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                  Realtor's Space
                </span>
              </h2>
              <p className="text-xl text-gray-600 mb-8 leading-relaxed">
                Based in <span className="font-semibold text-purple-600">Nyeri, Kenya</span>, we bring you the finest property listings with a premium user experience. Our platform combines luxury real estate with cutting-edge technology to help you find your perfect home.
              </p>
              
              {/* Stats */}
              <div className="grid grid-cols-3 gap-6 mb-8">
                <div className="text-center p-6 bg-white rounded-2xl shadow-lg hover-lift">
                  <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-pink-500 rounded-2xl flex items-center justify-center mx-auto mb-4">
                    <i className="fas fa-home text-white text-xl"></i>
                  </div>
                  <h3 className="text-3xl font-black bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent mb-2">40+</h3>
                  <p className="text-gray-600 font-medium">Properties Listed</p>
                </div>
                <div className="text-center p-6 bg-white rounded-2xl shadow-lg hover-lift">
                  <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-purple-500 rounded-2xl flex items-center justify-center mx-auto mb-4">
                    <i className="fas fa-heart text-white text-xl"></i>
                  </div>
                  <h3 className="text-3xl font-black bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-2">98%</h3>
                  <p className="text-gray-600 font-medium">Client Satisfaction</p>
                </div>
                <div className="text-center p-6 bg-white rounded-2xl shadow-lg hover-lift">
                  <div className="w-16 h-16 bg-gradient-to-r from-green-500 to-blue-500 rounded-2xl flex items-center justify-center mx-auto mb-4">
                    <i className="fas fa-award text-white text-xl"></i>
                  </div>
                  <h3 className="text-3xl font-black bg-gradient-to-r from-green-600 to-blue-600 bg-clip-text text-transparent mb-2">2+</h3>
                  <p className="text-gray-600 font-medium">Years Experience</p>
                </div>
              </div>
            </div>
            
            <div className="relative fade-in-up">
              <div className="relative">
                <img
                  src="https://images.unsplash.com/photo-1560518883-ce09059eeffa?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80"
                  alt="Luxury building"
                  className="rounded-3xl shadow-2xl w-full hover-lift"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-purple-600/20 to-transparent rounded-3xl"></div>
                
                {/* Floating Badge */}
                <div className="absolute -top-6 -right-6 bg-white rounded-2xl p-6 shadow-2xl">
                  <div className="flex items-center space-x-3">
                    <div className="w-12 h-12 bg-gradient-to-r from-green-400 to-blue-500 rounded-xl flex items-center justify-center">
                      <i className="fas fa-star text-white"></i>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Trusted by</p>
                      <p className="font-bold text-gray-900">500+ Clients</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="relative py-20 overflow-hidden">
        {/* Background */}
        <div className="absolute inset-0 bg-gradient-to-br from-purple-50 via-white to-pink-50"></div>
        <div className="absolute top-0 left-0 w-96 h-96 bg-purple-100 rounded-full blur-3xl opacity-30 -translate-x-48 -translate-y-48"></div>
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-pink-100 rounded-full blur-3xl opacity-30 translate-x-48 translate-y-48"></div>
        
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <div className="inline-flex items-center px-4 py-2 bg-gradient-to-r from-purple-100 to-pink-100 text-purple-700 rounded-full text-sm font-semibold mb-6">
              <i className="fas fa-concierge-bell mr-2"></i>
              Premium Services
            </div>
            <h2 className="text-4xl md:text-6xl font-black text-gray-900 mb-6 tracking-tight">
              Our Premium
              <span className="block bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                Services
              </span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
              Beyond listings - we provide 
              <span className="text-purple-600 font-semibold">complete property solutions</span> 
              tailored to your needs
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Custom Property Search */}
            <div className="group card-modern hover-lift p-8 text-center relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-purple-500/5 to-pink-500/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              <div className="relative z-10">
                <div className="w-20 h-20 bg-gradient-to-r from-purple-500 to-pink-500 rounded-3xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300">
                  <i className="fas fa-search-dollar text-2xl text-white"></i>
                </div>
                <h3 className="text-2xl font-bold text-gray-900 mb-4 group-hover:text-purple-600 transition-colors duration-300">
                  Custom Property Search
                </h3>
                <p className="text-gray-600 mb-6 leading-relaxed">
                  Can't find what you're looking for? Our expert agents will conduct a personalized property search based on your exact requirements.
                </p>
                <div className="mb-6">
                  <span className="inline-flex items-center px-3 py-1 bg-purple-100 text-purple-700 rounded-full text-sm font-semibold">
                    From KES 1,500
                  </span>
                </div>
                <a
                  href="https://wa.me/254757577018?text=Hi%20RealtorSpace,%20I'm%20interested%20in%20your%20Custom%20Property%20Search%20service"
                  className="inline-flex items-center px-6 py-3 bg-gradient-to-r from-green-500 to-green-600 text-white font-semibold rounded-xl hover:shadow-lg hover:shadow-green-500/25 transform hover:scale-105 transition-all duration-300"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <i className="fab fa-whatsapp mr-2"></i>
                  Get Started
                </a>
              </div>
            </div>

            {/* Moving Services */}
            <div className="group card-modern hover-lift p-8 text-center relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-blue-500/5 to-purple-500/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              <div className="relative z-10">
                <div className="w-20 h-20 bg-gradient-to-r from-blue-500 to-purple-500 rounded-3xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300">
                  <i className="fas fa-truck-moving text-2xl text-white"></i>
                </div>
                <h3 className="text-2xl font-bold text-gray-900 mb-4 group-hover:text-blue-600 transition-colors duration-300">
                  Professional Moving
                </h3>
                <p className="text-gray-600 mb-6 leading-relaxed">
                  Moving to your new property? Our trusted partners offer stress-free relocation services with care and professionalism.
                </p>
                <div className="mb-6">
                  <span className="inline-flex items-center px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm font-semibold">
                    Full Service Available
                  </span>
                </div>
                <a
                  href="https://wa.me/254757577018?text=Hi%20RealtorSpace,%20I%20need%20Moving%20Services"
                  className="inline-flex items-center px-6 py-3 bg-gradient-to-r from-green-500 to-green-600 text-white font-semibold rounded-xl hover:shadow-lg hover:shadow-green-500/25 transform hover:scale-105 transition-all duration-300"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <i className="fab fa-whatsapp mr-2"></i>
                  Get Started
                </a>
              </div>
            </div>

            {/* Property Viewing */}
            <div className="group card-modern hover-lift p-8 text-center relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-green-500/5 to-blue-500/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              <div className="relative z-10">
                <div className="w-20 h-20 bg-gradient-to-r from-green-500 to-blue-500 rounded-3xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300">
                  <i className="fas fa-house-user text-2xl text-white"></i>
                </div>
                <h3 className="text-2xl font-bold text-gray-900 mb-4 group-hover:text-green-600 transition-colors duration-300">
                  Guided Viewing
                </h3>
                <p className="text-gray-600 mb-6 leading-relaxed">
                  Want to see a property in person? Our agents will arrange professional viewings with neighborhood insights.
                </p>
                <div className="mb-6">
                  <span className="inline-flex items-center px-3 py-1 bg-green-100 text-green-700 rounded-full text-sm font-semibold">
                    From KES 500/viewing
                  </span>
                </div>
                <a
                  href="https://wa.me/254757577018?text=Hi%20RealtorSpace,%20I'd%20like%20to%20schedule%20a%20property%20viewing"
                  className="inline-flex items-center px-6 py-3 bg-gradient-to-r from-green-500 to-green-600 text-white font-semibold rounded-xl hover:shadow-lg hover:shadow-green-500/25 transform hover:scale-105 transition-all duration-300"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <i className="fab fa-whatsapp mr-2"></i>
                  Book Now
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="relative py-20 overflow-hidden">
        {/* Background */}
        <div className="absolute inset-0 bg-gradient-to-br from-blue-50 via-white to-green-50"></div>
        <div className="absolute top-0 right-0 w-96 h-96 bg-blue-100 rounded-full blur-3xl opacity-30 translate-x-48 -translate-y-48"></div>
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-green-100 rounded-full blur-3xl opacity-30 -translate-x-48 translate-y-48"></div>
        
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <div className="inline-flex items-center px-4 py-2 bg-gradient-to-r from-blue-100 to-green-100 text-blue-700 rounded-full text-sm font-semibold mb-6">
              <i className="fas fa-quote-left mr-2"></i>
              Client Stories
            </div>
            <h2 className="text-4xl md:text-6xl font-black text-gray-900 mb-6 tracking-tight">
              What Our Clients
              <span className="block bg-gradient-to-r from-blue-600 to-green-600 bg-clip-text text-transparent">
                Say About Us
              </span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
              Real stories from real people who found their 
              <span className="text-blue-600 font-semibold">dream homes</span> with us
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Testimonial 1 */}
            <div className="group card-modern hover-lift p-8 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-blue-500/5 to-green-500/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              <div className="relative z-10">
                {/* Stars */}
                <div className="flex items-center mb-6">
                  {[...Array(5)].map((_, i) => (
                    <i key={i} className="fas fa-star text-yellow-400 text-lg mr-1"></i>
                  ))}
                </div>
                
                {/* Quote */}
                <div className="mb-8">
                  <i className="fas fa-quote-left text-4xl text-blue-200 mb-4"></i>
                  <p className="text-xl text-gray-700 leading-relaxed font-medium">
                    "Realtor's Space made finding my dream home effortless. The virtual tours were incredible and saved me so much time!"
                  </p>
                </div>
                
                {/* Client Info */}
                <div className="flex items-center">
                  <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-green-500 rounded-full flex items-center justify-center mr-4 text-white font-bold text-xl">
                    SW
                  </div>
                  <div>
                    <h4 className="font-bold text-gray-900 text-lg">Sarah W.</h4>
                    <p className="text-blue-600 font-medium">Homeowner</p>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Testimonial 2 */}
            <div className="group card-modern hover-lift p-8 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-green-500/5 to-blue-500/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              <div className="relative z-10">
                {/* Stars */}
                <div className="flex items-center mb-6">
                  {[...Array(5)].map((_, i) => (
                    <i key={i} className="fas fa-star text-yellow-400 text-lg mr-1"></i>
                  ))}
                </div>
                
                {/* Quote */}
                <div className="mb-8">
                  <i className="fas fa-quote-left text-4xl text-green-200 mb-4"></i>
                  <p className="text-xl text-gray-700 leading-relaxed font-medium">
                    "As a landlord, I've never had such quality tenants. The platform attracts serious buyers and renters."
                  </p>
                </div>
                
                {/* Client Info */}
                <div className="flex items-center">
                  <div className="w-16 h-16 bg-gradient-to-r from-green-500 to-blue-500 rounded-full flex items-center justify-center mr-4 text-white font-bold text-xl">
                    JK
                  </div>
                  <div>
                    <h4 className="font-bold text-gray-900 text-lg">James K.</h4>
                    <p className="text-green-600 font-medium">Property Owner</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Home;
