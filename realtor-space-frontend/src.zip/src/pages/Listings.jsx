import { useState, useEffect } from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import PropertyCard from '../components/PropertyCard';
import { fallbackApi } from '../services/api';

const Listings = () => {
  const [properties, setProperties] = useState([]);
  const [filteredProperties, setFilteredProperties] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({
    propertyType: 'all',
    location: 'all',
    priceRange: 'all'
  });

  useEffect(() => {
    const loadProperties = async () => {
      try {
        const response = await fallbackApi.getProperties();
        setProperties(response.data.properties);
        setFilteredProperties(response.data.properties);
      } catch (error) {
        console.error('Error loading properties:', error);
      } finally {
        setLoading(false);
      }
    };

    loadProperties();
  }, []);

  const handleFilterChange = (filterType, value) => {
    const newFilters = { ...filters, [filterType]: value };
    setFilters(newFilters);
    applyFilters(newFilters);
  };

  const applyFilters = (currentFilters) => {
    let filtered = [...properties];

    // Filter by property type
    if (currentFilters.propertyType !== 'all') {
      filtered = filtered.filter(property => {
        const type = currentFilters.propertyType;
        if (type === 'single') return property.category === 'Single Room';
        if (type === 'one-bedroom') return property.category === 'One Bedroom';
        if (type === 'two-bedroom') return property.category === 'Two Bedroom';
        if (type === 'three-bedroom') return property.category.includes('Three Bedroom') || property.category.includes('+');
        if (type === 'apartment') return property.category === 'Apartment';
        if (type === 'house') return property.category === 'House';
        return true;
      });
    }

    // Filter by location
    if (currentFilters.location !== 'all') {
      filtered = filtered.filter(property =>
        property.location.toLowerCase().includes(currentFilters.location.toLowerCase())
      );
    }

    // Filter by price range
    if (currentFilters.priceRange !== 'all') {
      const [min, max] = currentFilters.priceRange.split('-').map(val =>
        val.endsWith('+') ? parseInt(val) : parseInt(val)
      );

      filtered = filtered.filter(property => {
        if (currentFilters.priceRange.endsWith('+')) {
          return property.price >= min;
        } else {
          return property.price >= min && property.price <= max;
        }
      });
    }

    setFilteredProperties(filtered);
  };

  return (
    <div className="min-h-screen container-fix">
      <Header />
      
      {/* Hero Section */}
      <section className="relative py-24 overflow-hidden">
        {/* Animated Background */}
        <div className="absolute inset-0 gradient-shift" style={{
          background: 'linear-gradient(135deg, #667eea 0%, #764ba2 50%, #f093fb 100%)'
        }}></div>
        
        {/* Floating Elements */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-10 left-10 w-32 h-32 bg-white/10 rounded-full blur-xl animate-pulse"></div>
          <div className="absolute bottom-10 right-10 w-40 h-40 bg-white/5 rounded-full blur-2xl float"></div>
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="fade-in-up">
            <h1 className="text-4xl md:text-6xl font-black text-white mb-6 tracking-tight">
              Premium Property
              <span className="block bg-gradient-to-r from-yellow-300 to-pink-300 bg-clip-text text-transparent">
                Listings
              </span>
            </h1>
            <p className="text-xl text-white/90 max-w-2xl mx-auto">
              Find your perfect home with our curated selection of luxury properties
            </p>
          </div>
        </div>
      </section>

      {/* Filter Section */}
      <section className="bg-white py-8 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
            {/* Property Type Filter */}
            <div>
              <label htmlFor="property-type" className="block text-sm font-medium text-gray-700 mb-2">
                Property Type
              </label>
              <select
                id="property-type"
                value={filters.propertyType}
                onChange={(e) => handleFilterChange('propertyType', e.target.value)}
                className="w-full border-gray-300 rounded-md shadow-sm focus:border-blue-500 focus:ring-blue-500"
              >
                <option value="all">All Types</option>
                <option value="single">Single Room</option>
                <option value="one-bedroom">One Bedroom</option>
                <option value="two-bedroom">Two Bedroom</option>
                <option value="three-bedroom">Three Bedroom+</option>
                <option value="apartment">Apartment</option>
                <option value="house">House</option>
              </select>
            </div>

            {/* Location Filter */}
            <div>
              <label htmlFor="location" className="block text-sm font-medium text-gray-700 mb-2">
                Location
              </label>
              <select
                id="location"
                value={filters.location}
                onChange={(e) => handleFilterChange('location', e.target.value)}
                className="w-full border-gray-300 rounded-md shadow-sm focus:border-blue-500 focus:ring-blue-500"
              >
                <option value="all">All Locations</option>
                <option value="nyeri">Nyeri</option>
                <option value="nairobi">Nairobi</option>
                <option value="nanyuki">Nanyuki</option>
                <option value="mombasa">Mombasa</option>
              </select>
            </div>

            {/* Price Range Filter */}
            <div>
              <label htmlFor="price-range" className="block text-sm font-medium text-gray-700 mb-2">
                Price Range
              </label>
              <select
                id="price-range"
                value={filters.priceRange}
                onChange={(e) => handleFilterChange('priceRange', e.target.value)}
                className="w-full border-gray-300 rounded-md shadow-sm focus:border-blue-500 focus:ring-blue-500"
              >
                <option value="all">All Prices</option>
                <option value="0-10000">Under KES 10,000</option>
                <option value="10000-30000">KES 10,000 - 30,000</option>
                <option value="30000-50000">KES 30,000 - 50,000</option>
                <option value="50000-100000">KES 50,000 - 100,000</option>
                <option value="100000+">KES 100,000+</option>
              </select>
            </div>

            {/* Clear Filters Button */}
            <div>
              <button
                onClick={() => {
                  setFilters({ propertyType: 'all', location: 'all', priceRange: 'all' });
                  setFilteredProperties(properties);
                }}
                className="w-full bg-gray-600 hover:bg-gray-700 text-white font-medium py-2 px-4 rounded-md transition-colors duration-200"
              >
                Clear Filters
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Properties Grid */}
      <section className="py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Results Count */}
          <div className="mb-8">
            <p className="text-gray-600">
              Showing {filteredProperties.length} of {properties.length} properties
            </p>
          </div>

          {/* Loading State */}
          {loading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <div key={i} className="bg-gray-200 rounded-lg h-80 animate-pulse"></div>
              ))}
            </div>
          ) : filteredProperties.length === 0 ? (
            /* No Results */
            <div className="text-center py-12">
              <div className="bg-gray-100 rounded-lg p-8">
                <i className="fas fa-home text-4xl text-gray-400 mb-4"></i>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">
                  No properties match your filters
                </h3>
                <p className="text-gray-600 mb-4">
                  Try adjusting your search criteria to see more results.
                </p>
                <button
                  onClick={() => {
                    setFilters({ propertyType: 'all', location: 'all', priceRange: 'all' });
                    setFilteredProperties(properties);
                  }}
                  className="bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-md transition-colors duration-200"
                >
                  Clear All Filters
                </button>
              </div>
            </div>
          ) : (
            /* Properties Grid */
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredProperties.map((property) => (
                <PropertyCard
                  key={property.id}
                  property={property}
                  className="hover-grow"
                />
              ))}
            </div>
          )}
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Listings;
