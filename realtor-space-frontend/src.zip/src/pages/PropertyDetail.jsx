import React, { useState, useEffect } from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { useParams } from 'react-router-dom';
import { fallbackApi } from '../services/api';

const PropertyDetail = () => {
  const { id } = useParams();
  const [property, setProperty] = useState(null);
  const [loading, setLoading] = useState(true);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  useEffect(() => {
    const loadProperty = async () => {
      try {
        const response = await fallbackApi.getProperties();
        const propertyData = response.data.properties.find(p => p.id == id);
        if (propertyData) {
          setProperty(propertyData);
        } else {
          // Handle property not found (redirect can be implemented here)
          console.error('Property not found');
        }
      } catch (error) {
        console.error('Error loading property:', error);
      } finally {
        setLoading(false);
      }
    };

    if (id) {
      loadProperty();
    }
  }, [id]);

  const formatPrice = (price) => {
    return new Intl.NumberFormat('en-KE', {
      style: 'currency',
      currency: 'KES',
      minimumFractionDigits: 0,
    }).format(price);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="bg-gray-200 h-10 w-10 rounded-full animate-spin mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading property details...</p>
        </div>
      </div>
    );
  }

  if (!property) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">Property not found</h1>
          <p className="text-gray-600">The property you're looking for doesn't exist.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Image Gallery */}
        <section className="mb-12">
          <div className="relative mb-8">
            <img
              src={property.images[currentImageIndex]}
              alt={property.name}
              className="w-full h-96 object-cover rounded-lg shadow-lg"
            />
            {property.images.length > 1 && (
              <div className="absolute inset-x-0 top-1/2 transform -translate-y-1/2 flex justify-between px-4">
                <button
                  onClick={() => setCurrentImageIndex((currentImageIndex - 1 + property.images.length) % property.images.length)}
                  className="bg-gray-800 bg-opacity-75 text-white p-2 rounded-full shadow-md hover:bg-opacity-100 transition-opacity"
                >
                  <i className="fas fa-chevron-left"></i>
                </button>
                <button
                  onClick={() => setCurrentImageIndex((currentImageIndex + 1) % property.images.length)}
                  className="bg-gray-800 bg-opacity-75 text-white p-2 rounded-full shadow-md hover:bg-opacity-100 transition-opacity"
                >
                  <i className="fas fa-chevron-right"></i>
                </button>
              </div>
            )}
          </div>

          {/* Thumbnail Gallery */}
          {property.images.length > 1 && (
            <div className="flex space-x-4 overflow-x-auto pb-4">
              {property.images.map((image, index) => (
                <img
                  key={index}
                  src={image}
                  alt={`${property.name} view ${index + 1}`}
                  onClick={() => setCurrentImageIndex(index)}
                  className={`w-20 h-20 object-cover rounded-lg cursor-pointer transition-opacity ${
                    index === currentImageIndex ? 'ring-2 ring-blue-500' : 'opacity-70 hover:opacity-100'
                  }`}
                />
              ))}
            </div>
          )}
        </section>

        {/* Property Details */}
        <section className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          {/* Main Info */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-lg shadow-lg p-8 mb-8">
              <div className="flex justify-between items-start mb-6">
                <div>
                  <h1 className="text-3xl font-bold text-gray-900 mb-2">{property.name}</h1>
                  <p className="text-xl text-gray-600 flex items-center">
                    <i className="fas fa-map-marker-alt mr-2"></i>
                    {property.location}
                  </p>
                </div>
                <div className="text-right">
                  <div className="text-3xl font-bold text-blue-600">
                    {formatPrice(property.price)}
                  </div>
                  <span className="text-gray-500">/month</span>
                </div>
              </div>

              <div className="flex space-x-6 mb-8 text-gray-600">
                <div className="flex items-center">
                  <i className="fas fa-bed text-blue-600 mr-2"></i>
                  <span>{property.bedrooms} Bedrooms</span>
                </div>
                <div className="flex items-center">
                  <i className="fas fa-bath text-blue-600 mr-2"></i>
                  <span>{property.bathrooms} Bathrooms</span>
                </div>
                <div className="flex items-center">
                  <i className="fas fa-ruler-combined text-blue-600 mr-2"></i>
                  <span>{property.area} sqft</span>
                </div>
              </div>

              <div className="border-t pt-6">
                <h2 className="text-xl font-semibold text-gray-900 mb-4">Description</h2>
                <p className="text-gray-600 leading-relaxed">{property.description}</p>
              </div>
            </div>

            {/* Amenities */}
            <div className="bg-white rounded-lg shadow-lg p-8 mb-8">
              <h2 className="text-xl font-semibold text-gray-900 mb-6">Amenities</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {property.amenities.map((amenity, index) => (
                  <div key={index} className="flex items-center text-gray-600">
                    <i className="fas fa-check text-green-500 mr-3"></i>
                    <span>{amenity}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Virtual Tour */}
            {property.virtualTour && (
              <div className="bg-white rounded-lg shadow-lg p-8">
                <h2 className="text-xl font-semibold text-gray-900 mb-6">Virtual Tour</h2>
                <div className="aspect-w-16 aspect-h-9">
                  <iframe
                    src={property.virtualTour}
                    title="Virtual Tour"
                    frameBorder="0"
                    className="w-full h-64 rounded-lg shadow-lg"
                    allowFullScreen
                  ></iframe>
                </div>
              </div>
            )}
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1">
            {/* Contact */}
            <div className="bg-white rounded-lg shadow-lg p-8 mb-8">
              <h2 className="text-xl font-semibold text-gray-900 mb-6">Contact Property Manager</h2>
              <div className="flex items-center mb-6">
                {property.management.photo && (
                  <img
                    src={property.management.photo}
                    alt="Manager"
                    className="h-16 w-16 object-cover rounded-full mr-4"
                  />
                )}
                <div>
                  <p className="text-gray-800 font-semibold">{property.management.name}</p>
                  <p className="text-gray-600">{property.management.type}</p>
                  <p className="text-gray-600 flex items-center mt-1">
                    <i className="fas fa-phone mr-2"></i>
                    {property.management.contact}
                  </p>
                </div>
              </div>
              <a
                href="https://wa.me/254757577018?text=Hi%20RealtorSpace,%20I'd%20like%20to%20schedule%20a%20property%20viewing"
                className="w-full bg-green-500 hover:bg-green-600 text-white font-medium py-3 px-4 rounded-md transition-colors duration-200 inline-flex items-center justify-center"
                target="_blank"
                rel="noopener noreferrer"
              >
                <i className="fab fa-whatsapp mr-2"></i>
                WhatsApp Us
              </a>
            </div>

            {/* Property Type Badge */}
            <div className="bg-blue-50 rounded-lg p-6">
              <h3 className="text-lg font-semibold text-blue-900 mb-2">Property Type</h3>
              <span className="bg-blue-600 text-white px-4 py-2 rounded-full text-sm font-medium">
                {property.category}
              </span>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default PropertyDetail;

