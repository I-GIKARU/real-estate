import { Link } from 'react-router-dom';

const Footer = () => {
  return (
    <>
      <footer className="relative bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 text-white overflow-hidden">
        {/* Enhanced Background Pattern */}
        <div className="absolute inset-0 opacity-20">
          <div className="absolute top-0 left-0 w-full h-full">
            <div className="absolute top-20 left-20 w-40 h-40 bg-gradient-to-r from-purple-400 to-pink-400 rounded-full blur-3xl opacity-30"></div>
            <div className="absolute bottom-20 right-20 w-60 h-60 bg-gradient-to-r from-blue-400 to-purple-400 rounded-full blur-3xl opacity-20"></div>
            <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-80 h-80 bg-gradient-to-r from-pink-400 to-purple-400 rounded-full blur-3xl opacity-10"></div>
          </div>
        </div>
        
        {/* Decorative Grid */}
        <div className="absolute inset-0 opacity-5">
          <div className="absolute inset-0" style={{
            backgroundImage: `radial-gradient(circle at 1px 1px, rgba(255,255,255,0.3) 1px, transparent 0)`,
            backgroundSize: '40px 40px'
          }}></div>
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-16">
            {/* Company Info */}
            <div className="md:col-span-2 space-y-8">
              <div className="flex items-center space-x-4">
                <div className="relative">
                  <div className="absolute inset-0 bg-gradient-to-r from-purple-400 to-pink-400 rounded-full blur-md opacity-30"></div>
                  <img 
                    src="/logo2.png" 
                    alt="Realtor's Space Logo" 
                    className="relative h-14 w-14 object-contain"
                  />
                </div>
                <h3 className="text-3xl font-bold bg-gradient-to-r from-purple-400 via-pink-400 to-purple-400 bg-clip-text text-transparent">
                  Realtor's Space
                </h3>
              </div>
              <p className="text-gray-300 text-lg leading-relaxed max-w-lg">
                Premium property listings with luxury experience. Your gateway to exceptional living in Kenya.
              </p>
              <div className="flex items-center text-gray-300 bg-white/5 backdrop-blur-sm rounded-lg p-3 w-fit">
                <i className="fas fa-map-marker-alt mr-3 text-purple-400"></i>
                <span>Nyeri, Kenya</span>
              </div>
              
              {/* Social Media */}
              <div className="flex space-x-4 pt-2">
                <a href="#" className="group relative w-12 h-12 bg-gradient-to-r from-purple-600 to-pink-600 rounded-full flex items-center justify-center hover:shadow-xl hover:shadow-purple-500/25 transition-all duration-300 hover:scale-110">
                  <i className="fab fa-facebook-f text-white group-hover:scale-110 transition-transform duration-300"></i>
                </a>
                <a href="#" className="group relative w-12 h-12 bg-gradient-to-r from-blue-600 to-purple-600 rounded-full flex items-center justify-center hover:shadow-xl hover:shadow-blue-500/25 transition-all duration-300 hover:scale-110">
                  <i className="fab fa-twitter text-white group-hover:scale-110 transition-transform duration-300"></i>
                </a>
                <a href="#" className="group relative w-12 h-12 bg-gradient-to-r from-pink-600 to-purple-600 rounded-full flex items-center justify-center hover:shadow-xl hover:shadow-pink-500/25 transition-all duration-300 hover:scale-110">
                  <i className="fab fa-instagram text-white group-hover:scale-110 transition-transform duration-300"></i>
                </a>
                <a href="#" className="group relative w-12 h-12 bg-gradient-to-r from-indigo-600 to-purple-600 rounded-full flex items-center justify-center hover:shadow-xl hover:shadow-indigo-500/25 transition-all duration-300 hover:scale-110">
                  <i className="fab fa-linkedin-in text-white group-hover:scale-110 transition-transform duration-300"></i>
                </a>
              </div>
            </div>

            {/* Quick Links */}
            <div className="space-y-6">
              <h3 className="text-xl font-bold text-white mb-6 relative">
                Quick Links
                <div className="absolute bottom-0 left-0 w-8 h-0.5 bg-gradient-to-r from-purple-400 to-pink-400 rounded-full"></div>
              </h3>
              <ul className="space-y-4">
                <li>
                  <Link 
                    to="/" 
                    className="text-gray-300 hover:text-white transition-all duration-300 flex items-center group hover:bg-white/5 p-2 rounded-lg"
                  >
                    <div className="w-6 h-6 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center mr-3 group-hover:shadow-lg group-hover:shadow-purple-500/25 transition-all duration-300">
                      <i className="fas fa-chevron-right text-xs text-white group-hover:translate-x-0.5 transition-transform duration-300"></i>
                    </div>
                    Home
                  </Link>
                </li>
                <li>
                  <Link 
                    to="/listings" 
                    className="text-gray-300 hover:text-white transition-all duration-300 flex items-center group hover:bg-white/5 p-2 rounded-lg"
                  >
                    <div className="w-6 h-6 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center mr-3 group-hover:shadow-lg group-hover:shadow-blue-500/25 transition-all duration-300">
                      <i className="fas fa-chevron-right text-xs text-white group-hover:translate-x-0.5 transition-transform duration-300"></i>
                    </div>
                    Listings
                  </Link>
                </li>
                <li>
                  <a 
                    href="/#about" 
                    className="text-gray-300 hover:text-white transition-all duration-300 flex items-center group hover:bg-white/5 p-2 rounded-lg"
                  >
                    <div className="w-6 h-6 bg-gradient-to-r from-green-500 to-blue-500 rounded-full flex items-center justify-center mr-3 group-hover:shadow-lg group-hover:shadow-green-500/25 transition-all duration-300">
                      <i className="fas fa-chevron-right text-xs text-white group-hover:translate-x-0.5 transition-transform duration-300"></i>
                    </div>
                    About Us
                  </a>
                </li>
                <li>
                  <a 
                    href="/#services" 
                    className="text-gray-300 hover:text-white transition-all duration-300 flex items-center group hover:bg-white/5 p-2 rounded-lg"
                  >
                    <div className="w-6 h-6 bg-gradient-to-r from-pink-500 to-purple-500 rounded-full flex items-center justify-center mr-3 group-hover:shadow-lg group-hover:shadow-pink-500/25 transition-all duration-300">
                      <i className="fas fa-chevron-right text-xs text-white group-hover:translate-x-0.5 transition-transform duration-300"></i>
                    </div>
                    Services
                  </a>
                </li>
                <li>
                  <a 
                    href="/#contact" 
                    className="text-gray-300 hover:text-white transition-all duration-300 flex items-center group hover:bg-white/5 p-2 rounded-lg"
                  >
                    <div className="w-6 h-6 bg-gradient-to-r from-indigo-500 to-purple-500 rounded-full flex items-center justify-center mr-3 group-hover:shadow-lg group-hover:shadow-indigo-500/25 transition-all duration-300">
                      <i className="fas fa-chevron-right text-xs text-white group-hover:translate-x-0.5 transition-transform duration-300"></i>
                    </div>
                    Contact
                  </a>
                </li>
              </ul>
            </div>

            {/* Contact Info */}
            <div className="space-y-6">
              <h3 className="text-xl font-bold text-white mb-6 relative">
                Contact Us
                <div className="absolute bottom-0 left-0 w-8 h-0.5 bg-gradient-to-r from-purple-400 to-pink-400 rounded-full"></div>
              </h3>
              <div className="space-y-6">
                <a href="tel:+254757577018" className="text-gray-300 hover:text-white transition-all duration-300 flex items-center group bg-white/5 backdrop-blur-sm rounded-xl p-4 hover:bg-white/10 hover:scale-105">
                  <div className="w-12 h-12 bg-gradient-to-r from-purple-600 to-pink-600 rounded-full flex items-center justify-center mr-4 group-hover:shadow-xl group-hover:shadow-purple-500/25 transition-all duration-300">
                    <i className="fas fa-phone text-white"></i>
                  </div>
                  <div>
                    <p className="text-xs text-gray-400 uppercase tracking-wider">Phone</p>
                    <span className="text-sm font-medium">+254 757 577 018</span>
                  </div>
                </a>
                <a href="mailto:realtorspace04@gmail.com" className="text-gray-300 hover:text-white transition-all duration-300 flex items-center group bg-white/5 backdrop-blur-sm rounded-xl p-4 hover:bg-white/10 hover:scale-105">
                  <div className="w-12 h-12 bg-gradient-to-r from-blue-600 to-purple-600 rounded-full flex items-center justify-center mr-4 group-hover:shadow-xl group-hover:shadow-blue-500/25 transition-all duration-300">
                    <i className="fas fa-envelope text-white"></i>
                  </div>
                  <div>
                    <p className="text-xs text-gray-400 uppercase tracking-wider">Email</p>
                    <span className="text-sm font-medium">realtorspace04@gmail.com</span>
                  </div>
                </a>
                <div className="text-gray-300 flex items-center bg-white/5 backdrop-blur-sm rounded-xl p-4">
                  <div className="w-12 h-12 bg-gradient-to-r from-green-600 to-blue-600 rounded-full flex items-center justify-center mr-4">
                    <i className="fas fa-map-marker-alt text-white"></i>
                  </div>
                  <div>
                    <p className="text-xs text-gray-400 uppercase tracking-wider">Location</p>
                    <span className="text-sm font-medium">Nyeri Town, Kenya</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Bottom Bar */}
          <div className="border-t border-gradient-to-r from-purple-500/20 to-pink-500/20 pt-12">
            <div className="flex flex-col md:flex-row justify-between items-center space-y-6 md:space-y-0">
              <div className="flex flex-col md:flex-row items-center space-y-2 md:space-y-0 md:space-x-4">
                <p className="text-gray-400 text-center md:text-left font-medium">
                  © 2025 Realtor's Space. All rights reserved.
                </p>
                <div className="hidden md:block w-1 h-1 bg-purple-400 rounded-full"></div>
                <p className="text-gray-500 text-sm text-center md:text-left">
                  Crafted with ❤️ in Kenya
                </p>
              </div>
              <div className="flex space-x-8">
                <a href="#" className="text-gray-400 hover:text-white transition-all duration-300 hover:scale-105 relative group">
                  <span>Privacy Policy</span>
                  <div className="absolute bottom-0 left-0 w-0 h-0.5 bg-gradient-to-r from-purple-400 to-pink-400 group-hover:w-full transition-all duration-300"></div>
                </a>
                <a href="#" className="text-gray-400 hover:text-white transition-all duration-300 hover:scale-105 relative group">
                  <span>Terms of Service</span>
                  <div className="absolute bottom-0 left-0 w-0 h-0.5 bg-gradient-to-r from-purple-400 to-pink-400 group-hover:w-full transition-all duration-300"></div>
                </a>
              </div>
            </div>
          </div>
        </div>
      </footer>

      {/* Floating WhatsApp Button */}
      <a
        href="https://wa.me/254757577018"
        className="fixed bottom-8 right-8 group z-50 transform transition-all duration-300 hover:scale-110"
        target="_blank"
        rel="noopener noreferrer"
      >
        <div className="relative">
          <div className="absolute inset-0 bg-gradient-to-r from-green-400 to-green-600 rounded-full blur-lg opacity-60 group-hover:opacity-80 transition-opacity duration-300"></div>
          <div className="relative w-16 h-16 bg-gradient-to-r from-green-500 to-green-600 rounded-full flex items-center justify-center shadow-2xl group-hover:shadow-green-500/50 transition-all duration-300">
            <i className="fab fa-whatsapp text-2xl text-white group-hover:scale-110 transition-transform duration-300"></i>
          </div>
        </div>
        <div className="absolute -top-12 left-1/2 transform -translate-x-1/2 bg-gray-900 text-white px-3 py-1 rounded-lg text-sm opacity-0 group-hover:opacity-100 transition-opacity duration-300 whitespace-nowrap">
          Chat with us
          <div className="absolute top-full left-1/2 transform -translate-x-1/2 w-0 h-0 border-l-4 border-r-4 border-t-4 border-transparent border-t-gray-900"></div>
        </div>
      </a>
    </>
  );
};

export default Footer;
