import { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const location = useLocation();

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const isActive = (path) => {
    return location.pathname === path;
  };

  // Handle scroll effect
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header className="relative">
      <nav className={`fixed w-full top-0 z-50 transition-all duration-500 ${
        isScrolled 
          ? 'bg-white/95 backdrop-blur-sm shadow-xl border-b border-gray-200/30 py-3' 
          : 'bg-white/15 backdrop-blur-md py-4'
      }`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center">
            {/* Logo */}
            <Link 
              to="/" 
              className="flex items-center space-x-2 group" 
              onClick={() => setIsMenuOpen(false)}
            >
              <div className="relative">
                <img 
                  src="/logo2.png" 
                  alt="Realtor's Space Logo" 
                  className="h-10 w-10 object-contain transition-transform duration-300 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-r from-purple-400 to-pink-400 opacity-0 group-hover:opacity-20 rounded-full transition-opacity duration-300"></div>
              </div>
              <div className="flex flex-col">
                <span className={`text-lg font-black tracking-tight transition-colors duration-300 ${
                  isScrolled ? 'text-gray-900' : 'text-white'
                }`}>Realtor's</span>
                <span className={`text-lg font-black tracking-tight -mt-2 transition-colors duration-300 ${
                  isScrolled ? 'text-gray-900' : 'text-white'
                }`}>Space</span>
              </div>
            </Link>

            {/* Desktop Navigation */}
            <div className="hidden lg:flex items-center space-x-1">
              <Link 
                to="/" 
                className={`relative px-4 py-2.5 text-sm font-semibold transition-all duration-300 rounded-xl group whitespace-nowrap ${
                  isActive('/')
                    ? isScrolled
                      ? 'text-purple-600 bg-purple-50'
                      : 'text-white bg-white/25'
                    : isScrolled
                      ? 'text-gray-700 hover:text-purple-600 hover:bg-purple-50'
                      : 'text-white hover:text-white hover:bg-white/15'
                }`}
              >
                <span className="relative z-10">Home</span>
                {isActive('/') && (
                  <div className="absolute inset-0 bg-gradient-to-r from-purple-500 to-pink-500 rounded-xl opacity-10"></div>
                )}
                <div className="absolute inset-0 bg-gradient-to-r from-purple-500 to-pink-500 rounded-xl opacity-0 group-hover:opacity-5 transition-opacity duration-300"></div>
              </Link>
              
              <Link 
                to="/listings" 
                className={`relative px-4 py-2.5 text-sm font-semibold transition-all duration-300 rounded-xl group whitespace-nowrap ${
                  isActive('/listings')
                    ? isScrolled
                      ? 'text-purple-600 bg-purple-50'
                      : 'text-white bg-white/25'
                    : isScrolled
                      ? 'text-gray-700 hover:text-purple-600 hover:bg-purple-50'
                      : 'text-white hover:text-white hover:bg-white/15'
                }`}
              >
                <span className="relative z-10">Listings</span>
                {isActive('/listings') && (
                  <div className="absolute inset-0 bg-gradient-to-r from-purple-500 to-pink-500 rounded-xl opacity-10"></div>
                )}
                <div className="absolute inset-0 bg-gradient-to-r from-purple-500 to-pink-500 rounded-xl opacity-0 group-hover:opacity-5 transition-opacity duration-300"></div>
              </Link>
              
              <a 
                href="/#about" 
                className={`relative px-4 py-2.5 text-sm font-semibold transition-all duration-300 rounded-xl group whitespace-nowrap ${
                  isScrolled
                    ? 'text-gray-700 hover:text-purple-600 hover:bg-purple-50'
                    : 'text-white hover:text-white hover:bg-white/15'
                }`}
              >
                <span className="relative z-10">About</span>
                <div className="absolute inset-0 bg-gradient-to-r from-purple-500 to-pink-500 rounded-xl opacity-0 group-hover:opacity-5 transition-opacity duration-300"></div>
              </a>
              
              <a 
                href="/#services" 
                className={`relative px-4 py-2.5 text-sm font-semibold transition-all duration-300 rounded-xl group whitespace-nowrap ${
                  isScrolled
                    ? 'text-gray-700 hover:text-purple-600 hover:bg-purple-50'
                    : 'text-white hover:text-white hover:bg-white/15'
                }`}
              >
                <span className="relative z-10">Services</span>
                <div className="absolute inset-0 bg-gradient-to-r from-purple-500 to-pink-500 rounded-xl opacity-0 group-hover:opacity-5 transition-opacity duration-300"></div>
              </a>
              
              <a 
                href="/#contact" 
                className={`relative px-4 py-2.5 text-sm font-semibold transition-all duration-300 rounded-xl group whitespace-nowrap ${
                  isScrolled
                    ? 'text-gray-700 hover:text-purple-600 hover:bg-purple-50'
                    : 'text-white hover:text-white hover:bg-white/15'
                }`}
              >
                <span className="relative z-10">Contact</span>
                <div className="absolute inset-0 bg-gradient-to-r from-purple-500 to-pink-500 rounded-xl opacity-0 group-hover:opacity-5 transition-opacity duration-300"></div>
              </a>
            </div>

            {/* CTA Button & Mobile Menu */}
            <div className="flex items-center space-x-4">
              {/* CTA Button (Desktop) */}
              <Link
                to="/listings"
                className="hidden lg:block px-6 py-2.5 bg-gradient-to-r from-purple-600 to-pink-600 text-white font-semibold rounded-xl hover:shadow-lg hover:shadow-purple-500/25 transform hover:scale-105 transition-all duration-300"
              >
                Get Started
              </Link>

              {/* Mobile menu button */}
              <button
                onClick={toggleMenu}
                className={`lg:hidden relative w-10 h-10 rounded-xl flex flex-col justify-center items-center transition-all duration-300 ${
                  isScrolled ? 'bg-gray-100 hover:bg-gray-200' : 'bg-white/10 hover:bg-white/20'
                }`}
              >
                <div className="w-6 h-0.5 bg-current mb-1 transition-all duration-300 transform origin-center" 
                     style={{ transform: isMenuOpen ? 'rotate(45deg) translate(0, 6px)' : 'none' }}></div>
                <div className={`w-6 h-0.5 bg-current mb-1 transition-all duration-300 ${
                  isMenuOpen ? 'opacity-0' : 'opacity-100'
                }`}></div>
                <div className="w-6 h-0.5 bg-current transition-all duration-300 transform origin-center" 
                     style={{ transform: isMenuOpen ? 'rotate(-45deg) translate(0, -6px)' : 'none' }}></div>
                <span className={`absolute inset-0 rounded-xl transition-colors duration-300 ${
                  isScrolled ? 'text-gray-700' : 'text-white'
                }`}></span>
              </button>
            </div>
          </div>

          {/* Mobile Navigation */}
          <div className={`lg:hidden overflow-hidden transition-all duration-500 ease-in-out ${
            isMenuOpen ? 'max-h-96 opacity-100 mt-6' : 'max-h-0 opacity-0'
          }`}>
            <div className="bg-white/95 backdrop-blur-xl rounded-2xl border border-gray-200/20 shadow-2xl p-6">
              <div className="space-y-3">
                {[
                  { to: '/', label: 'Home', icon: 'fas fa-home' },
                  { to: '/listings', label: 'Listings', icon: 'fas fa-building' },
                  { href: '/#about', label: 'About', icon: 'fas fa-info-circle' },
                  { href: '/#services', label: 'Services', icon: 'fas fa-concierge-bell' },
                  { href: '/#contact', label: 'Contact', icon: 'fas fa-envelope' }
                ].map((item) => {
                  const active = item.to && isActive(item.to);
                  const Component = item.to ? Link : 'a';
                  const props = item.to ? { to: item.to } : { href: item.href };
                  
                  return (
                    <Component
                      key={item.label}
                      {...props}
                      className={`flex items-center space-x-3 px-4 py-3 rounded-xl transition-all duration-300 ${
                        active
                          ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white shadow-lg'
                          : 'text-gray-700 hover:bg-purple-50 hover:text-purple-600'
                      }`}
                      onClick={() => setIsMenuOpen(false)}
                    >
                      <i className={`${item.icon} text-sm`}></i>
                      <span className="font-medium">{item.label}</span>
                      {active && (
                        <div className="ml-auto w-2 h-2 bg-white rounded-full animate-pulse"></div>
                      )}
                    </Component>
                  );
                })}
              </div>
              
              {/* Mobile CTA */}
              <div className="mt-6 pt-6 border-t border-gray-200">
                <Link
                  to="/listings"
                  className="w-full flex items-center justify-center px-6 py-3 bg-gradient-to-r from-purple-600 to-pink-600 text-white font-semibold rounded-xl hover:shadow-lg transition-all duration-300"
                  onClick={() => setIsMenuOpen(false)}
                >
                  <i className="fas fa-rocket mr-2"></i>
                  Get Started
                </Link>
              </div>
            </div>
          </div>
        </div>
      </nav>
      
      {/* Spacer for fixed navigation */}
      <div className="h-20"></div>
    </header>
  );
};

export default Header;
